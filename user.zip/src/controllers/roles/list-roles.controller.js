'use strict';

const { Roles, Permissions } = require('../../../sequelize/models');
const { Op } = require('sequelize');
const BaseController = require('../base-controller');

class ListRoles extends BaseController {
    static async execute(params = {}, user) {
        try {
            const { sortBy, sortColumn, pageSize, offsetValue, search } =
                params;
            const organizationId = user.organizationId;

            const query = {
                where: {
                    organizationId: organizationId,
                },
                include: [
                    {
                        model: Permissions,
                        as: 'permissions',
                        attributes: ['id', 'resource', 'accessType'],
                    },
                ],
                order: [
                    [
                        [
                            'id',
                            'name',
                            'organizationId',
                            'isDefault',
                            'canBeDeleted',
                            'createdAt',
                            'updatedAt',
                        ].includes(sortColumn)
                            ? sortColumn
                            : 'createdAt',
                        ['ASC', 'DESC'].includes(sortBy?.toUpperCase())
                            ? sortBy.toUpperCase()
                            : 'DESC',
                    ],
                ],
            };

            if (search) {
                query.where[Op.or] = [{ name: { [Op.like]: `%${search}%` } }];
            }

            if (pageSize !== undefined || offsetValue !== undefined) {
                query.limit = Math.max(1, parseInt(pageSize) || 10);
                query.offset = Math.max(0, parseInt(offsetValue) || 0);
            }

            const [roles, total] = await Promise.all([
                Roles.findAll(query),
                Roles.count({ where: query.where }),
            ]);

            return { roles, total };
        } catch (error) {
            throw error;
        }
    }
}

module.exports = ListRoles;
