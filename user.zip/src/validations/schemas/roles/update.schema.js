'use strict';

module.exports = {
    type: 'object',
    properties: {
        name: {
            type: 'string',
            minLength: 1,
            maxLength: 255,
        },
    },
    required: ['name'],
    additionalProperties: false,
};
